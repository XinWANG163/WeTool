function changep() {
    // var el = document.getElementById('photo')
    // el.src = '../assets/titleBar/cone.png'
    var inputObj = document.createElement('input')
    inputObj.setAttribute('id', '_ef');
    inputObj.setAttribute('type', 'file');
    inputObj.setAttribute("style", 'visibility:hidden');
    inputObj.setAttribute('accept', 'image/png,image/jpeg')
        // inputObj.setAttribute('onclick', 'getUrl()')
    document.body.appendChild(inputObj);
    inputObj.click();

}

function changeName() {
    alert("成功修改用户名！")

}

function jinggao() {
    alert("无法从这里退出！")
}


function deleteItem(event) {
    var con = confirm("确定删除记录？")
    if (con == true) {
        var btn = event.target.parentNode;
        var item = btn.parentNode;
        item.remove();
        alert("成功删除记录！")
    }

}

function loading() {

}
// 进度条
var n = 0;
// 取随机数
var n = 2;
n += Math.ceil(Math.random() * 800);
// 将当前数据的条数改为n

var load = document.getElementById('load');
var result = document.getElementById('result');
var i = -1;
var timer = setInterval(function() {
    if (i < n) {
        i += 1;
        load.style.width = (i / n) * 665 + 'px';
        loadResult.innerText = i + '/' + n;
    }
    if (i >= n) {
        var deleteTimer = setInterval(function() {
            // 删除当前节点的这个进度条
        }, 2000);
        clearInterval(timer);
    }
}, 1000);

// 点击显示内容
function showTextContent(event) {
    var aLi = event.target;
    if (aLi.tagName == "DIV") {
        var contentEl = aLi.children[0]
    }
    if (aLi.tagName == "SPAN" && aLi.className == "sendingText") {
        var contentEl = aLi.parentNode.children[0]
    }
    if (aLi.tagName == "BUTTON") {
        var contentEl = document.getElementById('show');
    }
    contentEl.setAttribute('id', 'show');
    var el = document.getElementById("show-detail-content")
    el.textContent = contentEl.textContent

    var list = document.getElementsByClassName('edit-content');
    for (var i = 0; i < list.length; i++) {
        list[i].setAttribute('style', 'display:block');
    }

}

// 点击显示发送对象
function showTo(event) {
    var el = document.getElementById("show-detail-content")
    el.textContent = "";
    // el.setAttribute('style', 'display:none');
}

function editTextContent(content) {
    var text = document.getElementById("show-detail-content")
    text.readOnly = false
}

function changeTextContent(content) {
    var newText = document.getElementById("show-detail-content")
    document.getElementById("show").textContent = newText.value
    text.readOnly = true
}